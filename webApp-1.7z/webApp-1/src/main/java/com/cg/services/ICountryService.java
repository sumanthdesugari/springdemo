package com.cg.services;

import java.util.List;

import com.cg.models.Country;

public interface ICountryService {
	public Country findByCode(String code);
	public void save(Country country);
	public List<Country> findAll();
	public void delete(String code);
	public void update(Country country);
	
}
